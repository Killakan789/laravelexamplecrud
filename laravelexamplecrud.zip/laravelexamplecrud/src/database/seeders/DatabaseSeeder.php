<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\Product::factory(20)->create();
        \App\Models\Counteragent::factory(20)->create();
        \App\Models\Main::factory(10)->create();
    }
}
